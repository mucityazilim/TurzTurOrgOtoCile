#ifndef _TURLAR_H
#define _TURLAR_H

typedef struct turlar {
	int id, fiyat, kontenjan; 
	char turYeri[20], basTarih[20] , bitTarih[20]; 	
} tur ;

void turEkle() ; 
void turListele () ; 
void turGuncelle () ; 
void turSil () ; 

int turMenu(); 
void turIslemleri();

#endif 

