#include "rezervasyon.h"
#include "musteri.h"
#include "turlar.h"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

rez r1; 
tur t1; 

void rezervasyonOlustur () 
{
	printf("\nRezervasyon olusturma ... \n") ; 
	
	FILE *numPtr= fopen("rezNumaralari.dat", "a+b"); 
	int numara =0; 
	while( fread ( &numara, sizeof(int), 1, numPtr ) !=NULL  )
	{				
	}
	numara++; 
	fwrite ( &numara, sizeof(int), 1, numPtr ) ; 
	
	fclose(numPtr);
	 
	r1.id= numara;
	
	musteriListele() ; 	
	printf("Musteri TC. No  :  ") ; scanf(" %[^\n]s", r1.musTC ); 
		
	// turListele() ; 	
	
	printf("\nTur listesi ... \n") ; 		
	FILE *tPtr= fopen("turlar.dat", "r+b") ; 
	int durum=0; 
	printf("\n%-10s%-30s%-15s%-20s%-20s%-20s \n", "NUMARA", "TUR YERI", "KONTENJAN", "FIYAT (TL)", "BAS-TARIH", "BIT-TARIH") ; 
	while(  fread (&t1, sizeof(tur), 1, tPtr  )  !=NULL  ) 
	{
		printf("%-10d%-30s%-15d%-20d%-20s%-20s \n", t1.id, t1.turYeri, t1.kontenjan, t1.fiyat, t1.basTarih, t1.bitTarih ); 
		durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir tur kaydi yok ! \n"); 
	
	
	//
	else 
	{
	printf("Tur No/ID       :  ") ; scanf(" %d", &r1.turID ); 
	printf("Kisi Sayisi     :  ") ; scanf(" %d", &r1.kisiSayisi ); 
	printf("Tarih           :  ") ; scanf(" %[^\n]s", r1.tarih ); 
	
	//
	rewind(tPtr) ; 
	while(  fread (&t1, sizeof(tur), 1, tPtr  )  !=NULL  ) 
	{
		if( r1.turID == t1.id  ) 
		break; 
	}	
	
	//
		
	
	r1.toplamUcret = r1.kisiSayisi * t1.fiyat ; 
	
	
	
	
	
	FILE *ptr= fopen("rezervasyonlar.dat", "a+b") ; 
	fwrite(&r1, sizeof(rez ), 1, ptr  ) ; 
	fclose(ptr); 
	printf("%d numarali rezervasyon kaydi yapildi \n", numara );	
			
	}
	
	fclose(tPtr); 	
	
}
void rezervasyonListele () 
{
	system("cls"); 
	printf("\nRezervasyon listeleme ... \n") ; 
		
	FILE *ptr= fopen("rezervasyonlar.dat", "r+b") ; 
	int durum=0; 

	printf("\n%-10s%-20s%-10s%-10s%-20s%-20s \n", "NUMARA", "TC.NO", "TUR-ID", "K-SAYISI", "REZ-TARIH", "TOPLAM UCRET") ; 

	while(  fread (&r1, sizeof(rez ), 1, ptr  )  !=NULL  ) 
	{
		printf("\n%-10d%-20s%-10d%-10d%-20s%-20d \n", r1.id, r1.musTC, r1.turID, r1.kisiSayisi, r1.tarih, r1.toplamUcret ); 
		durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir rezervasyon kaydi yok ! \n"); 
	
	fclose(ptr); 	
	
	
}
void rezervasyonGuncelle () 
{
	printf("\nRezervasyon Guncelleme \n") ; 
			
	FILE *ptr= fopen("rezervasyonlar.dat", "r+b") ; 
	int durum=0, numara, sayac=0 ; 

	printf("\n%-10s%-20s%-10s%-10s%-20s%-20s \n", "NUMARA", "TC.NO", "TUR-ID", "K-SAYISI", "REZ-TARIH", "TOPLAM UCRET") ; 

	while(  fread (&r1, sizeof(rez ), 1, ptr  )  !=NULL  ) 
	{
		printf("\n%-10d%-20s%-10d%-10d%-20s%-20d \n", r1.id, r1.musTC, r1.turID, r1.kisiSayisi, r1.tarih, r1.toplamUcret ); 
		durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir rezervasyon kaydi yok ! \n"); 
	else
	{
		rewind(ptr) ; 
		durum =0; 
		printf("Guncellemek istediginiz rezercasyon numarasi / ID  : ") ; scanf("%d", &numara  ) ; 
		
			while(  fread (&r1, sizeof(rez), 1, ptr  )  !=NULL  ) 
			{
				if( numara ==r1.id  )
				{									
					durum=1; 	
					break; 
				}
				sayac++; 			 		
			}
			
			if( durum ==0)
			printf("%d numarali/ID tur kaydi bulunamadi \n", numara  );  
			else
			{
				rewind(ptr) ; 
		 		durum =0; 
		 		printf("Guncellemek istediginiz verileri giriniz : \n\n"); 
		 	
		 	//
		 	printf("\nTur listesi ... \n") ; 		
			FILE *tPtr= fopen("turlar.dat", "r+b") ; 
			int durum=0; 
			printf("\n%-10s%-30s%-15s%-20s%-20s%-20s \n", "NUMARA", "TUR YERI", "KONTENJAN", "FIYAT (TL)", "BAS-TARIH", "BIT-TARIH") ; 
			while(  fread (&t1, sizeof(tur), 1, tPtr  )  !=NULL  ) 
			{
				printf("%-10d%-30s%-15d%-20d%-20s%-20s \n", t1.id, t1.turYeri, t1.kontenjan, t1.fiyat, t1.basTarih, t1.bitTarih ); 
				durum=1; 		
			}
			if(durum==0)
			printf("\nHer hangi bir tur kaydi yok ! \n"); 
			else 
			{
				printf("Tur No/ID         :  ") ; scanf(" %d", &r1.turID ); 
				printf("Kisi Sayisi       :  ") ; scanf(" %d", &r1.kisiSayisi ); 
				printf("Guncelleme Tarihi :  ") ; scanf(" %[^\n]s", r1.tarih ); 
								
				//
					FILE *tPtr = fopen("turlar.dat", "r+b") ; 
					while(  fread (&t1, sizeof(tur), 1, tPtr  )  !=NULL  ) 
					{
						if( r1.turID == t1.id  ) 
						break; 
					}	
					
				//
				
				r1.toplamUcret = r1.kisiSayisi * t1.fiyat ; 
				
				
				fseek ( ptr, (sayac) * sizeof(rez), 0  ) ; 				
				fwrite(&r1, sizeof(rez ), 1, ptr  ) ; 
				printf("Rezervasyon   guncelleme  tamamlandi \n");
				fclose(ptr)		 ; 			
			}		 	
		 	
		 	//	
				
			} 		
	}
	
	fclose(ptr); 	
	
	
	
	
}
void rezervasyonSil () 
{
	
	printf("\nRezervasyon kaydi silme  \n") ; 
			
	FILE *ptr= fopen("rezervasyonlar.dat", "r+b") ; 
	int durum=0, numara ; 

	printf("\n%-10s%-20s%-10s%-10s%-20s%-20s \n", "NUMARA", "TC.NO", "TUR-ID", "K-SAYISI", "REZ-TARIH", "TOPLAM UCRET") ; 
	
	while(  fread (&r1, sizeof(rez ), 1, ptr  )  !=NULL  ) 
	{
		printf("\n%-10d%-20s%-10d%-10d%-20s%-20d \n", r1.id, r1.musTC, r1.turID, r1.kisiSayisi, r1.tarih, r1.toplamUcret ); 
			durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir rezervasyon kaydi yok ! \n"); 
	else
	{
		rewind(ptr) ; 
		durum =0; 
		printf("Silmek istediginiz rezervasyon numarasi / ID  : ") ; scanf("%d", &numara  ) ; 
		
			while(  fread (&r1, sizeof(rez ), 1, ptr  )  !=NULL  ) 
			{
				if( numara ==r1.id  )
				{									
					durum=1; 	
					break; 
				}
			 		
			}
			
			if( durum ==0)
			printf("%d numarali/ID rezervasyon kaydi bulunamadi \n", numara  );  
			else
			{
				char tercih; 
				printf("%d numarali rezervasyon kaydini silmek istediginize emin misiniz (E/H)  : ", numara  ) ; scanf(" %c", &tercih ); 
				if( tercih == 'e' || tercih == 'E') 
				{
					rewind(ptr) ; 
					
					FILE *yedekPtr= fopen("yedek.dat", "w+b") ; 
			 		
			 		
					 	while(  fread (&r1, sizeof(rez ), 1, ptr  )  !=NULL  ) 
						{
							if(numara != r1.id   )
							{	
								fwrite (&r1, sizeof(rez ), 1, yedekPtr  ) ; 
							}					 		
						}
						
						fclose(ptr); 
						fclose(yedekPtr) ; 
						
						remove("rezervasyonlar.dat") ; 
						rename("yedek.dat", "rezervasyonlar.dat") ; 			 
					 
					printf("%d numarali/ID rezervasyon kaydi silindi \n", numara  ); 					
				}
				else
				printf("%d numarali rezervasyon kaydi silme islemi iptal edildi \n", numara ) ; 				
					
			} 		
	}
	
	fclose(ptr); 
	
	
	
	
}

int  rezervasyonMenu() 
{
	int secim; 
	printf("\n\n\tREZERVASYON ISLEMLERI \n\n"); 
	printf("\n\t1-Rezervasyon Olustur   \n") ; 
	printf("\n\t2-Rezervasyon Listele  \n") ; 
	printf("\n\t3-Rezervasyon Guncelle  \n") ; 
	printf("\n\t4-Rezervasyon Sil  \n") ; 	
	printf("\n\t0-Cikis Yap  \n") ; 
	printf("\n\tSeciminiz : ") ;  scanf("%d", &secim); 
	system("cls"); 
	return secim; 	
	
	
}

void rezervasyonIslemleri()  
{
	
	int secim= rezervasyonMenu(); 
	
	while( secim != 0 )
	{
		switch(secim )
		{
			case 1: rezervasyonOlustur(); break; 
			case 2: rezervasyonListele(); break; 
			case 3: rezervasyonGuncelle()  ;  break;  
			case 4: rezervasyonSil() ;   break;  
			
			default : printf("Hatali secim !  \n"); break; 
		}
		
		secim= rezervasyonMenu(); 		
	}
	
	
	printf("cikis yapildi ... ") ; 
	
	
	
}


