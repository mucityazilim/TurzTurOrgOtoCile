#include "turlar.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

tur t1; 

void turEkle() 
{
	printf("\nTur ekleme... \n") ; 
	
	FILE *numPtr= fopen("turNumaralari.dat", "a+b"); 
	int numara =0; 
	while( fread ( &numara, sizeof(int), 1, numPtr ) !=NULL  )
	{				
	}
	numara++; 
	fwrite ( &numara, sizeof(int), 1, numPtr ) ; 
	
	fclose(numPtr);
	 
	t1.id= numara;
	
	printf("Tur yeri ( Adi ) :  ") ; scanf(" %[^\n]s", t1.turYeri ); 
	printf("Kontenjan        :  ") ; scanf(" %d", &t1.kontenjan ); 
	printf("Fiyat   (TL)     :  ") ; scanf(" %d", &t1.fiyat ); 	
	printf("Tur Baslama Tarih:  ") ; scanf(" %[^\n]s", t1.basTarih ); 
	printf("Tur Bitis   Tarih:  ") ; scanf(" %[^\n]s", t1.bitTarih ); 
	
	FILE *ptr= fopen("turlar.dat", "a+b") ; 
	fwrite(&t1, sizeof(tur), 1, ptr  ) ; 
	fclose(ptr); 
	printf("%d numarali tur kaydi yapildi \n", numara ); 	
	
 } 
void turListele () 
{
	system("cls"); 
	printf("\nTur listeleme ... \n") ; 
		
	FILE *ptr= fopen("turlar.dat", "r+b") ; 
	int durum=0; 
	printf("\n%-10s%-30s%-15s%-20s%-20s%-20s \n", "NUMARA", "TUR YERI", "KONTENJAN", "FIYAT (TL)", "BAS-TARIH", "BIT-TARIH") ; 
	while(  fread (&t1, sizeof(tur), 1, ptr  )  !=NULL  ) 
	{
		printf("%-10d%-30s%-15d%-20d%-20s%-20s \n", t1.id, t1.turYeri, t1.kontenjan, t1.fiyat, t1.basTarih, t1.bitTarih ); 
		durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir tur kaydi yok ! \n"); 
	
	fclose(ptr); 	
}
void turGuncelle () 
{
	printf("\nTur Guncelleme \n") ; 
			
	FILE *ptr= fopen("turlar.dat", "r+b") ; 
	int durum=0, numara, sayac=0 ; 
	printf("\n%-10s%-30s%-15s%-20s%-20s%-20s \n", "NUMARA", "TUR YERI", "KONTENJAN", "FIYAT (TL)", "BAS-TARIH", "BIT-TARIH") ; 
	while(  fread (&t1, sizeof(tur), 1, ptr  )  !=NULL  ) 
	{
		printf("%-10d%-30s%-15d%-20d%-20s%-20s \n", t1.id, t1.turYeri, t1.kontenjan, t1.fiyat, t1.basTarih, t1.bitTarih ); 
		durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir tur kaydi yok ! \n"); 
	else
	{
		rewind(ptr) ; 
		durum =0; 
		printf("Guncellemek istediginiz tur numarasi / ID  : ") ; scanf("%d", &numara  ) ; 
		
			while(  fread (&t1, sizeof(tur), 1, ptr  )  !=NULL  ) 
			{
				if( numara ==t1.id  )
				{									
					durum=1; 	
					break; 
				}
			 	sayac++; 	
			}
			
			if( durum ==0)
			printf("%d numarali/ID tur kaydi bulunamadi \n", numara  );  
			else
			{
				rewind(ptr) ; 
		 		durum =0; 
		 		printf("Guncellemek istediginiz verileri giriniz : \n\n"); 
		 		
		 		printf("Tur yeri ( Adi ) :  ") ; scanf(" %[^\n]s", t1.turYeri ); 
				printf("Kontenjan        :  ") ; scanf(" %d", &t1.kontenjan ); 
				printf("Fiyat   (TL)     :  ") ; scanf(" %d", &t1.fiyat ); 	
				printf("Tur Baslama Tarih:  ") ; scanf(" %[^\n]s", t1.basTarih ); 
				printf("Tur Bitis   Tarih:  ") ; scanf(" %[^\n]s", t1.bitTarih ); 							
				
				
				fseek(ptr, (sayac) * sizeof(tur), 0 ) ; 
				fwrite(&t1, sizeof(tur), 1, ptr  ) ; 
				printf("Tur guncelleme  tamamlandi \n"); 		
				
			} 		
	}
	
	fclose(ptr); 	
}
void turSil () 
{
	printf("\nTur kaydi silme  \n") ; 
			
	FILE *ptr= fopen("turlar.dat", "r+b") ; 
	int durum=0, numara ; 
	printf("\n%-10s%-30s%-15s%-20s%-20s%-20s \n", "NUMARA", "TUR YERI", "KONTENJAN", "FIYAT (TL)", "BAS-TARIH", "BIT-TARIH") ; 
	while(  fread (&t1, sizeof(tur), 1, ptr  )  !=NULL  ) 
	{
		printf("%-10d%-30s%-15d%-20d%-20s%-20s \n", t1.id, t1.turYeri, t1.kontenjan, t1.fiyat, t1.basTarih, t1.bitTarih ); 
		durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir tur kaydi yok ! \n"); 
	else
	{
		rewind(ptr) ; 
		durum =0; 
		printf("Silmek istediginiz tur numarasi / ID  : ") ; scanf("%d", &numara  ) ; 
		
			while(  fread (&t1, sizeof(tur), 1, ptr  )  !=NULL  ) 
			{
				if( numara ==t1.id  )
				{									
					durum=1; 	
					break; 
				}
			 		
			}
			
			if( durum ==0)
			printf("%d numarali/ID tur kaydi bulunamadi \n", numara  );  
			else
			{
				char tercih; 
				printf("%d numarali tur kaydini silmek istediginize emin misiniz (E/H)  : ", numara  ) ; scanf(" %c", &tercih ); 
				if( tercih == 'e' || tercih == 'E') 
				{
					rewind(ptr) ; 
					FILE *yedekPtr= fopen("yedek.dat", "w+b") ; 
			 		
			 		
					 	while(  fread (&t1, sizeof(tur), 1, ptr  )  !=NULL  ) 
						{
							if( numara !=t1.id  )
							{	
								fwrite (&t1, sizeof(tur), 1, yedekPtr  ) ; 
							}					 		
						}
						
						fclose(ptr); 
						fclose(yedekPtr) ; 
						
						remove("turlar.dat") ; 
						rename("yedek.dat", "turlar.dat") ; 			 
					 
					printf("%d numarali/ID tur kaydi silindi \n", numara  ); 					
				}
				else
				printf("%d numarali tur kaydi silme islemi iptal edildi \n", numara ) ; 				
					
			} 		
	}
	
	fclose(ptr); 
	
}

int turMenu()
{
	
	int secim; 
	printf("\n\n\tTUR ISLEMLERI \n\n"); 
	printf("\n\t1-Tur Ekle   \n") ; 
	printf("\n\t2-Tur Listele  \n") ; 
	printf("\n\t3-Tur Guncelle  \n") ; 
	printf("\n\t4-Tur Sil  \n") ; 	
	printf("\n\t0-Cikis Yap  \n") ; 
	printf("\n\tSeciminiz : ") ;  scanf("%d", &secim); 
	system("cls"); 
	return secim; 	
	
}

void turIslemleri()
{
	int secim= turMenu(); 
	
	while( secim != 0 )
	{
		switch(secim )
		{
			case 1: turEkle(); break; 
			case 2: turListele(); break; 
			case 3: turGuncelle()  ;  break;  
			case 4: turSil() ;   break;  
			
			default : printf("Hatali secim !  \n"); break; 
		}
		
		secim= turMenu(); 		
	}
	
	
	printf("cikis yapildi ... ") ; 
	
	
	
}
