#ifndef _REZERVASYON_H
#define _REZERVASYON_H

typedef struct Rezervasyon {
	int id, turID,  kisiSayisi, toplamUcret; 
	char musTC[20], tarih[20] ; 	
} rez  ;


void rezervasyonOlustur () ; 
void rezervasyonListele () ; 
void rezervasyonGuncelle () ; 
void rezervasyonSil () ; 

int rezervasyonMenu(); 

void rezervasyonIslemleri()  ; 





#endif 


