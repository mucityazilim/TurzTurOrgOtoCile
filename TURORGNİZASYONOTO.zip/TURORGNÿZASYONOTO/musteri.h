#ifndef _MUSTERI_H
#define _MUSTERI_H

typedef struct Musteriler {
	char tc[20], adSoyad[30], dTarih[20], dYeri[20], cinsiyet, adres[30], tel[20], eposta[30]; 	
	
}musteri ;


void musteriEkle() ; 
void musteriListele () ; 
void musteriGuncelle () ; 
void musteriSil () ; 

int musteriMenu(); 
void musteriIslemleri() ; 

#endif 



