#include "musteri.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


musteri m1; 


void musteriEkle() 
{
	printf("\nMusteri ekleme... \n") ; 
	
	printf("TC. No.     :   ") ; scanf(" %[^\n]s", m1.tc ); 
	printf("Ad Soyad    :   ") ; scanf(" %[^\n]s", m1.adSoyad ); 
	printf("Dogum Tarih :   ") ; scanf(" %[^\n]s", m1.dTarih ); 
	printf("Dogum Yeri  :   ") ; scanf(" %[^\n]s", m1.dYeri ); 
	printf("Cinsiyet    : ") ; scanf(" %[^\n]s", &m1.cinsiyet ); 
	printf("Adres       :   ") ; scanf(" %[^\n]s", m1.adres ); 
	printf("Telefon     :  ") ; scanf(" %[^\n]s", m1.tel ); 
	printf("e Posta     :   ") ; scanf(" %[^\n]s", m1.eposta ); 
	
	
	FILE *ptr= fopen("musteriler.dat", "a+b") ; 
	fwrite(&m1, sizeof(musteri ), 1, ptr  ) ; 
	fclose(ptr); 
	printf("%s TC/No kisisi kaydi yapildi \n", m1.tc ); 		
	
}
void musteriListele () 
{
	system("cls"); 
	printf("\nMusteri listeleme ... \n") ; 
		
	FILE *ptr= fopen("musteriler.dat", "r+b") ; 
	int durum=0; 
	printf("\n%-12s%-30s%-15s%-20s%-10s%-30s%-20s%-30s \n", "TC.NO", "AD-SOYAD", "D-TARIH", "D-YERI", "CINSIYET", "ADRES", "TELEFON", "E-POSTA" ) ; 
	while(  fread (&m1, sizeof(musteri ), 1, ptr  )  !=NULL  ) 
	{
		printf("\n%-12s%-30s%-15s%-20s%-10c%-30s%-20s%-30s \n", m1.tc, m1.adSoyad, m1.dTarih, m1.dYeri, m1.cinsiyet, m1.adres, m1.tel, m1.eposta  ); 
		durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir tur kaydi yok ! \n"); 
	
	fclose(ptr); 		
	
	
}
void musteriGuncelle () 
{
	printf("\nMusteri Guncelleme \n") ; 
			
	FILE *ptr= fopen("musteriler.dat", "r+b") ; 
	int durum=0, sayac=0 ; 
	char tc[20]; 

	printf("\n%-12s%-30s%-15s%-20s%-10s%-30s%-20s%-30s \n", "TC.NO", "AD-SOYAD", "D-TARIH", "D-YERI", "CINSIYET", "ADRES", "TELEFON", "E-POSTA" ) ; 

	while(  fread (&m1, sizeof(musteri ), 1, ptr  )  !=NULL  ) 
	{
		printf("\n%-12s%-30s%-15s%-20s%-10c%-30s%-20s%-30s \n", m1.tc, m1.adSoyad, m1.dTarih, m1.dYeri, m1.cinsiyet, m1.adres, m1.tel, m1.eposta  ); 
			durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir kisi kaydi yok ! \n"); 
	else
	{
		rewind(ptr) ; 
		durum =0; 
		printf("Guncellemek istediginiz musteri TC.NO / ID  : ") ; scanf(" %[^\n]s", &tc  ) ; 
		
			while(  fread (&m1, sizeof(musteri ), 1, ptr  )  !=NULL  ) 
			{
				if( strcmp( tc, m1.tc ) ==0    )
				{									
					durum=1; 	
					break; 
				}
			 		
			}
			
			if( durum ==0)
			printf("%s TC/ID  kaydi bulunamadi \n",  tc   );  
			else
			{
				rewind(ptr) ; 
		 		durum =0; 
		 		printf("Guncellemek istediginiz verileri giriniz : \n\n"); 
		 		
		 		printf("TC. No.     :   ") ; scanf(" %[^\n]s", m1.tc ); 
				printf("Ad Soyad    :   ") ; scanf(" %[^\n]s", m1.adSoyad ); 
				printf("Dogum Tarih :   ") ; scanf(" %[^\n]s", m1.dTarih ); 
				printf("Dogum Yeri  :   ") ; scanf(" %[^\n]s", m1.dYeri ); 
				printf("Cinsiyet    : ") ; scanf(" %[^\n]s", &m1.cinsiyet ); 
				printf("Adres       :   ") ; scanf(" %[^\n]s", m1.adres ); 
				printf("Telefon     :  ") ; scanf(" %[^\n]s", m1.tel ); 
				printf("e Posta     :   ") ; scanf(" %[^\n]s", m1.eposta ); 
								 
				 
				 
				 fseek(ptr, (sayac) *sizeof(musteri), 0 ) ; 
				fwrite(&m1, sizeof(musteri ), 1, ptr  ) ; 
				printf("Kisi bilgileri  guncellendi \n"); 		
				
			} 		
	}
	
	fclose(ptr); 
	
	
	
	
}
void musteriSil () 
{
	
	printf("\nMusteri kaydi silme  \n") ; 
			
	FILE *ptr= fopen("musteriler.dat", "r+b") ; 
	int durum=0; 
	char tc[20] ; 
	
	printf("\n%-12s%-30s%-15s%-20s%-10s%-30s%-20s%-30s \n", "TC.NO", "AD-SOYAD", "D-TARIH", "D-YERI", "CINSIYET", "ADRES", "TELEFON", "E-POSTA" ) ; 

	while(  fread (&m1, sizeof(musteri ), 1, ptr  )  !=NULL  ) 
	{
		printf("\n%-12s%-30s%-15s%-20s%-10c%-30s%-20s%-30s \n", m1.tc, m1.adSoyad, m1.dTarih, m1.dYeri, m1.cinsiyet, m1.adres, m1.tel, m1.eposta  ); 
		durum=1; 		
	}
	if(durum==0)
	printf("\nHer hangi bir Musteri kaydi yok ! \n"); 
	else
	{
		rewind(ptr) ; 
		durum =0; 
		printf("Silmek istediginiz Musteri TC / ID  : ") ; scanf(" %[^\n]s", tc   ) ; 
		
			while(  fread (&m1, sizeof(musteri ), 1, ptr  )  !=NULL  ) 
			{
				if( strcmp( tc, m1.tc  ) ==0    )
				{									
					durum=1; 	
					break; 
				}
			 		
			}
			
			if( durum ==0)
			printf("%s numarali/TC kisi kaydi bulunamadi \n", tc );  
			else
			{
				char tercih; 
				printf("%s TC/numarali kisi kaydini silmek istediginize emin misiniz (E/H)  : ", tc  ) ; scanf(" %c", &tercih ); 
				if( tercih == 'e' || tercih == 'E') 
				{
					rewind(ptr) ; 
					FILE *yedekPtr= fopen("yedek.dat", "w+b") ; 
			 		
			 		
					 	while(  fread (&m1, sizeof(musteri ), 1, ptr  )  !=NULL  ) 
						{
							if(  strcmp( tc, m1.tc  ) !=0   )
							{	
								fwrite (&m1, sizeof(musteri ), 1, yedekPtr  ) ; 
							}					 		
						}
						
						fclose(ptr); 
						fclose(yedekPtr) ; 
						
						remove("musteriler.dat") ; 
						rename("yedek.dat", "musteriler.dat") ; 			 
					 
					printf("%s TC/ID kisi kaydi silindi \n", tc  ); 					
				}
				else
				printf("%s TC/numarali kisi kaydi silme islemi iptal edildi \n", tc  ) ; 				
					
			} 		
	}
	
	fclose(ptr); 
	
	
	
}

int musteriMenu()
{
	int secim; 
	printf("\n\n\tMUSTERI ISLEMLERI \n\n"); 
	printf("\n\t1-Musteri Ekle   \n") ; 
	printf("\n\t2-Musteri Listele  \n") ; 
	printf("\n\t3-Musteri Guncelle  \n") ; 
	printf("\n\t4-Musteri Sil  \n") ; 	
	printf("\n\t0-Cikis Yap  \n") ; 
	printf("\n\tSeciminiz : ") ;  scanf("%d", &secim); 
	system("cls"); 
	return secim; 	
	
	
	
	
}

void musteriIslemleri() 
{
	int secim= musteriMenu(); 
	
	while( secim != 0 )
	{
		switch(secim )
		{
			case 1: musteriEkle(); break; 
			case 2: musteriListele(); break; 
			case 3: musteriGuncelle()  ;  break;  
			case 4: musteriSil() ;   break;  
			
			default : printf("Hatali secim !  \n"); break; 
		}
		
		secim= musteriMenu(); 		
	}
	
	
	printf("cikis yapildi ... ") ; 
	
	
	
	
}

