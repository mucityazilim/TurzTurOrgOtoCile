#include <stdio.h>
#include <stdlib.h>
#include "turlar.h"
#include  "musteri.h"
#include "rezervasyon.h"
// MODULER  YAPI �LE
// TUR�ZM TUR. ORG. OTOMS (C dili ile) 
// Mucit Yaz�l�m - Sad�k �AH�N

int menu() 
{
	int secim; 
	printf("\n\n\tTURIZM TUR ORGANIZASYON OTOMASYONU \n\n"); 
	printf("\n\t1-TUR ISLEMLERI \n") ; 
	printf("\n\t2-MUSTERI ISLEMLERI \n") ; 
	printf("\n\t3-REZERVASYON ISLEMLERI \n") ; 
	printf("\n\t0-Programi Kapat \n") ; 
	printf("\n\tSeciminiz : ") ;  scanf("%d", &secim); 
	system("cls"); 
	return secim; 	
	
}

int main(int argc, char *argv[]) {
	
	int secim= menu(); 
	
	while( secim != 0 )
	{
		switch(secim )
		{
			case 1: turIslemleri(); break; 
			case 2: musteriIslemleri(); break; 
			case 3: rezervasyonIslemleri(); break;  
			default : printf("Hatali secim !  \n"); break; 
		}
		
		secim= menu(); 		
	}
	
	
	printf("Program kapatildi ... ") ; 
		
	
	return 0;
}
